/** Automatically generated file. DO NOT MODIFY */
package com.subbu.aryasamaj;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}